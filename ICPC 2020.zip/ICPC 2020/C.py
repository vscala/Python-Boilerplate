#Problem C

import sys
import math
from math import gcd,floor,sqrt,log

sys.setrecursionlimit(100000000)
mod = 1000000007

ISEQ = lambda: map(int(), input().split())
FSEQ = lambda: map(float(), input().split())
SSEQ = lambda: input().split()
INT = lambda: int(input())
STR = lambda: input()


